import { body } from "express-validator";

import User from "../models/User.js";
import { logActivity } from "../services/activityService.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { generateToken } from "../utils/generateToken.js";
import { isValidRollNumber } from "../utils/rollNumber.js";

export const signupValidation = [
  body("name").trim().notEmpty().withMessage("Full name is required"),
  body("rollNumber")
    .trim()
    .custom((value) => isValidRollNumber(value))
    .withMessage("Roll number must be a 10 digit 2023/2024 college roll number"),
  body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  body("confirmPassword")
    .custom((value, { req }) => value === req.body.password)
    .withMessage("Passwords do not match")
];

export const loginValidation = [
  body("rollNumber")
    .trim()
    .custom((value) => isValidRollNumber(value))
    .withMessage("Invalid roll number"),
  body("password").notEmpty().withMessage("Password is required")
];

export const signup = asyncHandler(async (req, res) => {
  const { name, rollNumber, password } = req.body;

  const existingUser = await User.findOne({ rollNumber });
  if (existingUser) {
    const error = new Error("Roll number already registered");
    error.statusCode = 409;
    throw error;
  }

  const user = await User.create({ name, rollNumber, password });

  await logActivity({
    actorId: user._id,
    action: "user.signup",
    details: `${user.name} registered with roll number ${user.rollNumber}`
  });

  res.status(201).json({
    success: true,
    data: {
      user: {
        id: user._id,
        name: user.name,
        rollNumber: user.rollNumber,
        role: user.role
      },
      token: generateToken(user)
    }
  });
});

export const login = asyncHandler(async (req, res) => {
  const { rollNumber, password } = req.body;
  const user = await User.findOne({ rollNumber });

  if (!user || !(await user.comparePassword(password))) {
    const error = new Error("Invalid roll number or password");
    error.statusCode = 401;
    throw error;
  }

  await logActivity({
    actorId: user._id,
    action: "user.login",
    details: `${user.name} logged in`
  });

  res.json({
    success: true,
    data: {
      user: {
        id: user._id,
        name: user.name,
        rollNumber: user.rollNumber,
        role: user.role
      },
      token: generateToken(user)
    }
  });
});

export const getProfile = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: req.user
  });
});
