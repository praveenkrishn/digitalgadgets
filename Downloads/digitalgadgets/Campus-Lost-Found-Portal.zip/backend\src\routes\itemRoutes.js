import express from "express";

import {
  createItem,
  deleteItem,
  getItemById,
  getItems,
  getMyItems,
  itemQueryValidation,
  itemValidation
} from "../controllers/itemController.js";
import { protect } from "../middleware/authMiddleware.js";
import { upload } from "../middleware/uploadMiddleware.js";
import { handleValidation } from "../middleware/validateMiddleware.js";

const router = express.Router();

router.get("/", itemQueryValidation, handleValidation, getItems);
router.get("/mine", protect, getMyItems);
router.get("/:id", getItemById);
router.post("/", protect, upload.single("image"), itemValidation, handleValidation, createItem);
router.delete("/:id", protect, deleteItem);

export default router;
