import { Link, NavLink, Outlet } from "react-router-dom";
import { useEffect, useState } from "react";

import { useAuth } from "../context/AuthContext.jsx";

const MainLayout = () => {
  const { isAuthenticated, logout, user } = useAuth();
  const [theme, setTheme] = useState(() => localStorage.getItem("campus-theme") || "light");

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("campus-theme", theme);
  }, [theme]);

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link className="brand" to="/">
          <span className="brand-mark">CLF</span>
          <div>
            <strong>Campus Lost & Found Portal</strong>
            <p>Built for secure college recovery workflows</p>
          </div>
        </Link>
        <nav className="nav">
          <NavLink to="/">Home</NavLink>
          {isAuthenticated ? <NavLink to="/dashboard">Dashboard</NavLink> : null}
          {isAuthenticated ? <NavLink to="/report/lost">Report Lost</NavLink> : null}
          {isAuthenticated ? <NavLink to="/report/found">Report Found</NavLink> : null}
          {user?.role === "admin" ? <NavLink to="/admin">Admin</NavLink> : null}
          <button className="button button--ghost" onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
            {theme === "light" ? "Dark Mode" : "Light Mode"}
          </button>
          {isAuthenticated ? (
            <button className="button button--ghost" onClick={logout}>
              Logout
            </button>
          ) : (
            <div className="nav__auth">
              <NavLink to="/login">Login</NavLink>
              <Link className="button" to="/signup">
                Sign Up
              </Link>
            </div>
          )}
        </nav>
      </header>
      <main className="page">
        <Outlet />
      </main>
    </div>
  );
};

export default MainLayout;
