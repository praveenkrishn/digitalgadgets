import express from "express";

import { getProfile, login, loginValidation, signup, signupValidation } from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";
import { handleValidation } from "../middleware/validateMiddleware.js";

const router = express.Router();

router.post("/signup", signupValidation, handleValidation, signup);
router.post("/login", loginValidation, handleValidation, login);
router.get("/me", protect, getProfile);

export default router;
