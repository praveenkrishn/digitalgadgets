import { useEffect, useState } from "react";

import api from "../api/client";
import ClaimRequestList from "../components/ClaimRequestList.jsx";
import ItemCard from "../components/ItemCard.jsx";
import SectionHeader from "../components/SectionHeader.jsx";

const AdminPage = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  const loadAdmin = async () => {
    try {
      const response = await api.get("/admin/overview");
      setData(response.data.data);
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to load admin panel");
    }
  };

  useEffect(() => {
    loadAdmin();
  }, []);

  const deleteItem = async (itemId) => {
    await api.delete(`/admin/items/${itemId}`);
    loadAdmin();
  };

  const updateClaim = async (claimId, status) => {
    await api.patch(`/claims/${claimId}`, { status });
    loadAdmin();
  };

  if (error) {
    return <div className="alert">{error}</div>;
  }

  if (!data) {
    return <p className="muted">Loading admin overview...</p>;
  }

  return (
    <div className="stack-lg">
      <section className="stats-grid">
        <div className="card stat-card"><strong>{data.summary.totalUsers}</strong><span>Users</span></div>
        <div className="card stat-card"><strong>{data.summary.totalItems}</strong><span>Items</span></div>
        <div className="card stat-card"><strong>{data.summary.totalClaims}</strong><span>Claims</span></div>
        <div className="card stat-card"><strong>{data.summary.verifiedItems}</strong><span>Verified</span></div>
      </section>

      <section className="stack">
        <SectionHeader title="Platform Users" description="Roll-number verified accounts across the portal." />
        <div className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Roll Number</th>
                <th>Role</th>
              </tr>
            </thead>
            <tbody>
              {data.users.map((user) => (
                <tr key={user._id}>
                  <td>{user.name}</td>
                  <td>{user.rollNumber}</td>
                  <td>{user.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="stack">
        <SectionHeader title="All Items" description="Moderate spam or fake reports when needed." />
        <div className="grid">
          {data.items.map((item) => (
            <div key={item._id} className="stack">
              <ItemCard item={item} />
              <button className="button button--ghost" onClick={() => deleteItem(item._id)}>
                Delete Report
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="stack">
        <SectionHeader title="All Claims" description="Review and manually resolve claim disputes." />
        <ClaimRequestList claims={data.claims} canModerate onAction={updateClaim} />
      </section>

      <section className="stack">
        <SectionHeader title="Activity Logs" description="Recent platform actions for operational visibility." />
        <div className="stack">
          {data.logs.map((log) => (
            <div key={log._id} className="card">
              <strong>{log.action}</strong>
              <p>{log.details}</p>
              <span className="muted small">{new Date(log.createdAt).toLocaleString()}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AdminPage;
