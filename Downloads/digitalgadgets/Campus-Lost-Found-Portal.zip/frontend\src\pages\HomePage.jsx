import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import api from "../api/client";
import ItemCard from "../components/ItemCard.jsx";
import SectionHeader from "../components/SectionHeader.jsx";
import { categories } from "../utils/constants";

const HomePage = () => {
  const [items, setItems] = useState([]);
  const [filters, setFilters] = useState({
    keyword: "",
    category: "",
    status: "",
    location: "",
    startDate: "",
    endDate: "",
    sort: "latest"
  });

  useEffect(() => {
    const fetchItems = async () => {
      const response = await api.get("/items", { params: filters });
      setItems(response.data.data);
    };

    fetchItems();
  }, [filters]);

  const recentItems = useMemo(() => items.slice(0, 6), [items]);

  return (
    <div className="stack-lg">
      <section className="hero">
        <div>
          <p className="eyebrow">Smart recovery network</p>
          <h1>Campus Lost & Found Portal</h1>
          <p>
            Report missing items, publish found objects, review intelligent match suggestions, and complete secure claim handoffs with roll-number-verified access.
          </p>
          <div className="button-row">
            <Link className="button" to="/signup">
              Start Reporting
            </Link>
            <a className="button button--ghost" href="#search">
              Search Items
            </a>
          </div>
        </div>
        <div className="card hero-stats">
          <div>
            <strong>Verified identity</strong>
            <p>Only valid 2023 and 2024 college roll numbers can register.</p>
          </div>
          <div>
            <strong>Intelligent matching</strong>
            <p>Items are matched using keywords, locations, categories, and dates.</p>
          </div>
          <div>
            <strong>Secure claiming</strong>
            <p>Owners and admins can review claim evidence before verification.</p>
          </div>
        </div>
      </section>

      <section id="search" className="card search-panel">
        <SectionHeader title="Search & Filter" description="Find lost, found, claimed, or verified items across campus." />
        <div className="search-grid">
          <input
            placeholder="Search title or description"
            value={filters.keyword}
            onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
          />
          <select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })}>
            <option value="">All Categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
          <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}>
            <option value="">All Statuses</option>
            <option value="lost">Lost</option>
            <option value="found">Found</option>
            <option value="claimed">Claimed</option>
            <option value="verified">Verified</option>
          </select>
          <input
            placeholder="Location"
            value={filters.location}
            onChange={(e) => setFilters({ ...filters, location: e.target.value })}
          />
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
          />
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
          />
          <select value={filters.sort} onChange={(e) => setFilters({ ...filters, sort: e.target.value })}>
            <option value="latest">Latest First</option>
            <option value="oldest">Oldest First</option>
          </select>
        </div>
      </section>

      <section className="stack">
        <SectionHeader
          title="Recent Reports"
          description="A live feed of the latest campus reports."
          action={
            <div className="button-row">
              <Link className="button" to="/report/lost">Report Lost</Link>
              <Link className="button button--ghost" to="/report/found">Report Found</Link>
            </div>
          }
        />
        <div className="grid">
          {recentItems.map((item) => (
            <ItemCard key={item._id} item={item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
