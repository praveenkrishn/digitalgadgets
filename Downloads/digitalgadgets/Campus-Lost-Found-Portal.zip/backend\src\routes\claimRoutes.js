import express from "express";

import {
  claimValidation,
  createClaim,
  getIncomingClaims,
  updateClaimStatus
} from "../controllers/claimController.js";
import { protect } from "../middleware/authMiddleware.js";
import { handleValidation } from "../middleware/validateMiddleware.js";

const router = express.Router();

router.get("/incoming", protect, getIncomingClaims);
router.post("/:itemId", protect, claimValidation, handleValidation, createClaim);
router.patch("/:claimId", protect, updateClaimStatus);

export default router;
