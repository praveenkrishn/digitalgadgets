export const ROLL_NUMBER_REGEX = /^(2023|2024)\d{6}$/;

export const isValidRollNumber = (value) => ROLL_NUMBER_REGEX.test(String(value || ""));
