import dayjs from "dayjs";

const NotificationList = ({ notifications = [], onRead }) => (
  <div className="stack">
    {notifications.map((notification) => (
      <div key={notification._id} className={`card notification ${notification.readStatus ? "is-read" : ""}`}>
        <div className="notification__row">
          <div>
            <strong>{notification.type.toUpperCase()}</strong>
            <p>{notification.message}</p>
          </div>
          {!notification.readStatus && onRead ? (
            <button className="button button--ghost" onClick={() => onRead(notification._id)}>
              Mark Read
            </button>
          ) : null}
        </div>
        <span className="muted small">{dayjs(notification.createdAt).format("DD MMM YYYY, hh:mm A")}</span>
      </div>
    ))}
    {!notifications.length ? <p className="muted">No notifications yet.</p> : null}
  </div>
);

export default NotificationList;
