import Item from "../models/Item.js";

const tokenize = (text = "") =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2);

const keywordScore = (sourceTokens, candidateTokens) => {
  const overlap = sourceTokens.filter((token) => candidateTokens.includes(token));
  return new Set(overlap).size;
};

const locationScore = (sourceLocation, candidateLocation) => {
  const source = sourceLocation.toLowerCase();
  const candidate = candidateLocation.toLowerCase();
  return source.includes(candidate) || candidate.includes(source) ? 2 : 0;
};

const dateScore = (sourceDate, candidateDate) => {
  const oneDay = 1000 * 60 * 60 * 24;
  const diffDays = Math.abs(new Date(sourceDate) - new Date(candidateDate)) / oneDay;

  if (diffDays <= 1) return 3;
  if (diffDays <= 3) return 2;
  if (diffDays <= 7) return 1;
  return 0;
};

export const computeMatchScore = (sourceItem, candidateItem) => {
  const sourceTokens = tokenize(`${sourceItem.title} ${sourceItem.description}`);
  const candidateTokens = tokenize(`${candidateItem.title} ${candidateItem.description}`);

  let score = 0;
  score += keywordScore(sourceTokens, candidateTokens) * 2;
  score += sourceItem.category === candidateItem.category ? 4 : 0;
  score += locationScore(sourceItem.location, candidateItem.location);
  score += dateScore(sourceItem.date, candidateItem.date);
  return score;
};

export const findPossibleMatches = async (item, limit = 5) => {
  const targetReportType = item.reportType === "lost" ? "found" : "lost";
  const candidates = await Item.find({
    _id: { $ne: item._id },
    reportType: targetReportType,
    category: item.category
  }).populate("userId", "name rollNumber");

  return candidates
    .map((candidate) => ({
      ...candidate.toObject(),
      matchScore: computeMatchScore(item, candidate)
    }))
    .filter((candidate) => candidate.matchScore >= 4)
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, limit);
};
