import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext.jsx";

const initialForm = {
  name: "",
  rollNumber: "",
  password: "",
  confirmPassword: ""
};

const AuthPage = ({ mode }) => {
  const isSignup = mode === "signup";
  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { authenticate } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      await authenticate(mode, form);
      navigate("/dashboard");
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="auth-grid">
      <div className="hero-panel">
        <p className="eyebrow">College-verified access</p>
        <h1>{isSignup ? "Create your secure campus account" : "Welcome back to the recovery desk"}</h1>
        <p>
          Use your college roll number to securely report missing items, review matches, and manage claim requests.
        </p>
      </div>
      <form className="card auth-card" onSubmit={handleSubmit}>
        <h2>{isSignup ? "Sign Up" : "Login"}</h2>
        {error ? <div className="alert">{error}</div> : null}
        {isSignup ? (
          <label>
            Full Name
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </label>
        ) : null}
        <label>
          Roll Number
          <input
            value={form.rollNumber}
            onChange={(e) => setForm({ ...form, rollNumber: e.target.value.replace(/\D/g, "") })}
            maxLength={10}
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            minLength={6}
            required
          />
        </label>
        {isSignup ? (
          <label>
            Confirm Password
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              minLength={6}
              required
            />
          </label>
        ) : null}
        <button className="button" disabled={loading} type="submit">
          {loading ? "Please wait..." : isSignup ? "Create Account" : "Login"}
        </button>
        <p className="muted">
          {isSignup ? "Already registered?" : "Need an account?"}{" "}
          <Link to={isSignup ? "/login" : "/signup"}>{isSignup ? "Login" : "Sign up"}</Link>
        </p>
      </form>
    </section>
  );
};

export default AuthPage;
