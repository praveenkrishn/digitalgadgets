import dayjs from "dayjs";
import { Link } from "react-router-dom";

import StatusBadge from "./StatusBadge.jsx";

const ItemCard = ({ item }) => (
  <article className="card item-card">
    <div className="item-card__header">
      <div>
        <p className="eyebrow">{item.reportType}</p>
        <h3>{item.title}</h3>
      </div>
      <StatusBadge status={item.status} />
    </div>
    <p className="muted">{item.description}</p>
    <div className="item-card__meta">
      <span>{item.category}</span>
      <span>{item.location}</span>
      <span>{dayjs(item.date).format("DD MMM YYYY")}</span>
    </div>
    <Link className="button button--ghost" to={`/items/${item._id}`}>
      View Details
    </Link>
  </article>
);

export default ItemCard;
