import { useState } from "react";
import { useNavigate } from "react-router-dom";

import api from "../api/client";
import { categories, locations } from "../utils/constants";

const emptyForm = {
  title: "",
  category: "Electronics",
  description: "",
  date: "",
  location: "",
  contactPreference: "email",
  storageLocation: ""
};

const ReportItemPage = ({ reportType }) => {
  const [form, setForm] = useState(emptyForm);
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const isFound = reportType === "found";

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const formData = new FormData();
      Object.entries({
        ...form,
        reportType
      }).forEach(([key, value]) => formData.append(key, value));

      if (file) {
        formData.append("image", file);
      }

      const response = await api.post("/items", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });

      navigate(`/items/${response.data.data.item._id}`);
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to submit report");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="form-shell">
      <form className="card form-card" onSubmit={handleSubmit}>
        <p className="eyebrow">{isFound ? "Found item report" : "Lost item report"}</p>
        <h1>{isFound ? "Help return a found item" : "Report something you lost"}</h1>
        {error ? <div className="alert">{error}</div> : null}
        <div className="form-grid">
          <label>
            Item Title
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </label>
          <label>
            Category
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </label>
          <label className="form-grid__full">
            Detailed Description
            <textarea
              rows="4"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              required
            />
          </label>
          <label>
            {isFound ? "Date Found" : "Date Lost"}
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required />
          </label>
          <label>
            Campus Location
            <select value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} required>
              <option value="">Select location</option>
              {locations.map((location) => (
                <option key={location} value={location}>
                  {location}
                </option>
              ))}
            </select>
          </label>
          <label className="form-grid__full">
            Need another location?
            <input
              placeholder="Add a more precise landmark or classroom"
              onChange={(e) => setForm({ ...form, location: e.target.value })}
            />
          </label>
          <label>
            Upload Image
            <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          {isFound ? (
            <label>
              Storage Location
              <input
                placeholder="Security Office / With Me"
                value={form.storageLocation}
                onChange={(e) => setForm({ ...form, storageLocation: e.target.value })}
              />
            </label>
          ) : (
            <label>
              Contact Preference
              <select
                value={form.contactPreference}
                onChange={(e) => setForm({ ...form, contactPreference: e.target.value })}
              >
                <option value="email">Email</option>
                <option value="in-app chat">In-app chat</option>
              </select>
            </label>
          )}
        </div>
        <button className="button" disabled={loading} type="submit">
          {loading ? "Submitting..." : "Submit Report"}
        </button>
      </form>
    </section>
  );
};

export default ReportItemPage;
