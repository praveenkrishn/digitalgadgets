const ClaimRequestList = ({ claims = [], onAction, canModerate = false }) => (
  <div className="stack">
    {claims.map((claim) => (
      <article key={claim._id} className="card">
        <div className="split">
          <div>
            <h3>{claim.itemId?.title || "Item removed"}</h3>
            <p className="muted">
              Claimed by {claim.claimantId?.name} ({claim.claimantId?.rollNumber})
            </p>
          </div>
          <span className={`pill pill--${claim.status}`}>{claim.status}</span>
        </div>
        <p><strong>Proof:</strong> {claim.proofDescription}</p>
        {claim.additionalNotes ? <p><strong>Notes:</strong> {claim.additionalNotes}</p> : null}
        {canModerate && claim.status === "pending" ? (
          <div className="button-row">
            <button className="button" onClick={() => onAction(claim._id, "approved")}>
              Approve
            </button>
            <button className="button button--ghost" onClick={() => onAction(claim._id, "rejected")}>
              Reject
            </button>
          </div>
        ) : null}
      </article>
    ))}
    {!claims.length ? <p className="muted">No claim requests to review.</p> : null}
  </div>
);

export default ClaimRequestList;
