import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import api from "../api/client";
import ClaimRequestList from "../components/ClaimRequestList.jsx";
import ItemCard from "../components/ItemCard.jsx";
import SectionHeader from "../components/SectionHeader.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const ItemDetailPage = () => {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const [data, setData] = useState(null);
  const [claimForm, setClaimForm] = useState({ proofDescription: "", additionalNotes: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const loadItem = async () => {
    const response = await api.get(`/items/${id}`);
    setData(response.data.data);
  };

  useEffect(() => {
    loadItem().catch((requestError) => {
      setError(requestError.response?.data?.message || "Unable to load item");
    });
  }, [id]);

  const handleClaim = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");

    try {
      await api.post(`/claims/${id}`, claimForm);
      setSuccess("Claim request submitted successfully.");
      setClaimForm({ proofDescription: "", additionalNotes: "" });
      loadItem();
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to submit claim");
    }
  };

  const handleClaimAction = async (claimId, status) => {
    await api.patch(`/claims/${claimId}`, { status });
    loadItem();
  };

  if (error && !data) {
    return <div className="alert">{error}</div>;
  }

  if (!data) {
    return <p className="muted">Loading item details...</p>;
  }

  const { item, possibleMatches, claims } = data;
  const canModerate = user && (user.id === item.userId?._id || user.role === "admin");

  return (
    <div className="stack-lg">
      <section className="detail-grid">
        <article className="card detail-card">
          <div className="split">
            <div>
              <p className="eyebrow">{item.reportType} report</p>
              <h1>{item.title}</h1>
            </div>
            <StatusBadge status={item.status} />
          </div>
          <p>{item.description}</p>
          <div className="detail-meta">
            <span><strong>Category:</strong> {item.category}</span>
            <span><strong>Date:</strong> {dayjs(item.date).format("DD MMM YYYY")}</span>
            <span><strong>Location:</strong> {item.location}</span>
            <span><strong>Reported by:</strong> {item.userId?.name} ({item.userId?.rollNumber})</span>
            {item.storageLocation ? <span><strong>Storage:</strong> {item.storageLocation}</span> : null}
            <span><strong>Contact:</strong> {item.contactPreference || "N/A"}</span>
          </div>
          {item.imageUrl ? <img alt={item.title} className="detail-image" src={item.imageUrl} /> : null}
        </article>

        <aside className="card">
          <SectionHeader title="Claim Item" description="Provide proof so the finder or admin can verify ownership." />
          {success ? <div className="success">{success}</div> : null}
          {error ? <div className="alert">{error}</div> : null}
          {isAuthenticated ? (
            <form className="stack" onSubmit={handleClaim}>
              <label>
                Proof Description
                <textarea
                  rows="4"
                  value={claimForm.proofDescription}
                  onChange={(e) => setClaimForm({ ...claimForm, proofDescription: e.target.value })}
                  required
                />
              </label>
              <label>
                Additional Notes
                <textarea
                  rows="3"
                  value={claimForm.additionalNotes}
                  onChange={(e) => setClaimForm({ ...claimForm, additionalNotes: e.target.value })}
                />
              </label>
              <button className="button" type="submit">Submit Claim</button>
            </form>
          ) : (
            <p className="muted">Login to submit a claim request.</p>
          )}
        </aside>
      </section>

      <section className="stack">
        <SectionHeader title="Possible Matches" description="Suggested by category, keywords, date, and location proximity." />
        <div className="grid">
          {possibleMatches.map((match) => (
            <ItemCard key={match._id} item={match} />
          ))}
          {!possibleMatches.length ? <p className="muted">No strong matches yet.</p> : null}
        </div>
      </section>

      <section className="stack">
        <SectionHeader title="Claim Activity" description="Ownership requests attached to this item." />
        <ClaimRequestList claims={claims} canModerate={canModerate} onAction={handleClaimAction} />
      </section>
    </div>
  );
};

export default ItemDetailPage;
