import { createContext, useContext, useEffect, useMemo, useState } from "react";

import api from "../api/client";

const AuthContext = createContext(null);

const decodeTokenExpiry = (token) => {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.exp ? payload.exp * 1000 : null;
  } catch {
    return null;
  }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("campus-user");
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem("campus-token"));

  useEffect(() => {
    if (!token) return undefined;

    const expiry = decodeTokenExpiry(token);
    if (!expiry) return undefined;

    const remaining = expiry - Date.now();

    if (remaining <= 0) {
      localStorage.removeItem("campus-token");
      localStorage.removeItem("campus-user");
      setToken(null);
      setUser(null);
      return undefined;
    }

    const timer = window.setTimeout(() => {
      localStorage.removeItem("campus-token");
      localStorage.removeItem("campus-user");
      setToken(null);
      setUser(null);
      window.location.href = "/login";
    }, remaining);

    return () => window.clearTimeout(timer);
  }, [token]);

  const authenticate = async (mode, payload) => {
    const endpoint = mode === "signup" ? "/auth/signup" : "/auth/login";
    const response = await api.post(endpoint, payload);
    const authData = response.data.data;

    setUser(authData.user);
    setToken(authData.token);
    localStorage.setItem("campus-token", authData.token);
    localStorage.setItem("campus-user", JSON.stringify(authData.user));
    return authData.user;
  };

  const logout = () => {
    localStorage.removeItem("campus-token");
    localStorage.removeItem("campus-user");
    setUser(null);
    setToken(null);
  };

  const value = useMemo(
    () => ({
      user,
      token,
      isAuthenticated: Boolean(user && token),
      authenticate,
      logout
    }),
    [token, user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
