export const categories = ["Electronics", "Books", "ID Cards", "Accessories", "Others"];

export const locations = [
  "Library 2nd Floor",
  "Engineering Block",
  "Main Cafeteria",
  "Computer Lab 3",
  "Auditorium",
  "Hostel A Lobby",
  "Campus Gate",
  "Security Office"
];

export const statusColors = {
  lost: "status-lost",
  found: "status-found",
  claimed: "status-claimed",
  verified: "status-verified"
};
