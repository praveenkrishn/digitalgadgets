import { body } from "express-validator";

import Claim from "../models/Claim.js";
import Item from "../models/Item.js";
import { logActivity } from "../services/activityService.js";
import { createNotification } from "../services/notificationService.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const claimValidation = [
  body("proofDescription").trim().notEmpty().withMessage("Proof description is required"),
  body("additionalNotes").optional().trim()
];

export const createClaim = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.itemId).populate("userId", "name");

  if (!item) {
    const error = new Error("Item not found");
    error.statusCode = 404;
    throw error;
  }

  if (item.status === "verified") {
    const error = new Error("This item has already been verified");
    error.statusCode = 400;
    throw error;
  }

  if (item.reportType !== "found") {
    const error = new Error("Only found items can be claimed");
    error.statusCode = 400;
    throw error;
  }

  const existingClaim = await Claim.findOne({
    itemId: item._id,
    claimantId: req.user._id,
    status: "pending"
  });

  if (existingClaim) {
    const error = new Error("You already have a pending claim for this item");
    error.statusCode = 409;
    throw error;
  }

  const claim = await Claim.create({
    itemId: item._id,
    claimantId: req.user._id,
    proofDescription: req.body.proofDescription,
    additionalNotes: req.body.additionalNotes || ""
  });

  item.claimCount += 1;
  item.status = "claimed";
  await item.save();

  await createNotification({
    userId: item.userId._id,
    type: "claim",
    message: `${req.user.name} submitted a claim request for "${item.title}".`
  });

  await logActivity({
    actorId: req.user._id,
    action: "claim.created",
    details: `${req.user.name} created a claim for ${item.title}`
  });

  res.status(201).json({
    success: true,
    data: claim
  });
});

export const updateClaimStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;

  if (!["approved", "rejected"].includes(status)) {
    const error = new Error("Status must be approved or rejected");
    error.statusCode = 400;
    throw error;
  }

  const claim = await Claim.findById(req.params.claimId)
    .populate("claimantId", "name rollNumber")
    .populate({
      path: "itemId",
      populate: { path: "userId", select: "name role" }
    });

  if (!claim) {
    const error = new Error("Claim not found");
    error.statusCode = 404;
    throw error;
  }

  const isOwner = claim.itemId.userId._id.toString() === req.user._id.toString();
  const isAdmin = req.user.role === "admin";

  if (!isOwner && !isAdmin) {
    const error = new Error("You cannot update this claim");
    error.statusCode = 403;
    throw error;
  }

  claim.status = status;
  await claim.save();

  claim.itemId.status = status === "approved" ? "verified" : "found";
  await claim.itemId.save();

  await createNotification({
    userId: claim.claimantId._id,
    type: "claim",
    message: `Your claim for "${claim.itemId.title}" was ${status}.`
  });

  await logActivity({
    actorId: req.user._id,
    action: "claim.updated",
    details: `${req.user.name} marked a claim as ${status} for ${claim.itemId.title}`
  });

  res.json({
    success: true,
    data: claim
  });
});

export const getIncomingClaims = asyncHandler(async (req, res) => {
  const ownedItems = await Item.find({ userId: req.user._id }).select("_id");
  const itemIds = ownedItems.map((item) => item._id);

  const claims = await Claim.find({ itemId: { $in: itemIds } })
    .populate("claimantId", "name rollNumber")
    .populate("itemId", "title status reportType")
    .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: claims
  });
});
