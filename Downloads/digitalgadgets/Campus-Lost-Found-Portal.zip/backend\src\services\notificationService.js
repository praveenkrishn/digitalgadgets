import Notification from "../models/Notification.js";

export const createNotification = async ({ userId, message, type = "system" }) => {
  if (!userId) {
    return null;
  }

  return Notification.create({
    userId,
    message,
    type
  });
};
