import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import api from "../api/client";
import ClaimRequestList from "../components/ClaimRequestList.jsx";
import ItemCard from "../components/ItemCard.jsx";
import NotificationList from "../components/NotificationList.jsx";
import SectionHeader from "../components/SectionHeader.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const DashboardPage = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const { user } = useAuth();

  const loadDashboard = async () => {
    try {
      const response = await api.get("/dashboard");
      setData(response.data.data);
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to load dashboard");
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const handleClaimAction = async (claimId, status) => {
    await api.patch(`/claims/${claimId}`, { status });
    loadDashboard();
  };

  const handleRead = async (id) => {
    await api.patch(`/notifications/${id}/read`);
    loadDashboard();
  };

  if (error) {
    return <div className="alert">{error}</div>;
  }

  if (!data) {
    return <p className="muted">Loading dashboard...</p>;
  }

  return (
    <div className="stack-lg">
      <section className="dashboard-hero">
        <div>
          <p className="eyebrow">Welcome back</p>
          <h1>{user?.name}</h1>
          <p className="muted">Manage your reports, claim requests, and notifications from a single recovery console.</p>
        </div>
        <div className="stats-grid">
          <div className="card stat-card"><strong>{data.stats.reportedLost}</strong><span>Lost Reports</span></div>
          <div className="card stat-card"><strong>{data.stats.reportedFound}</strong><span>Found Reports</span></div>
          <div className="card stat-card"><strong>{data.stats.pendingClaims}</strong><span>Pending Claims</span></div>
          <div className="card stat-card"><strong>{data.stats.unreadNotifications}</strong><span>Unread Alerts</span></div>
        </div>
      </section>

      <section className="stack">
        <SectionHeader
          title="Your Recent Reports"
          description="Track every item you have posted."
          action={<Link className="button" to="/report/lost">New Report</Link>}
        />
        <div className="grid">
          {data.items.map((item) => (
            <ItemCard key={item._id} item={item} />
          ))}
        </div>
      </section>

      <section className="dashboard-columns">
        <div>
          <SectionHeader title="Claim Requests" description="Review incoming ownership requests." />
          <ClaimRequestList claims={data.claimRequests} canModerate onAction={handleClaimAction} />
        </div>
        <div>
          <SectionHeader title="Notifications" description="Stay on top of matches and approvals." />
          <NotificationList notifications={data.notifications} onRead={handleRead} />
        </div>
      </section>
    </div>
  );
};

export default DashboardPage;
