import Claim from "../models/Claim.js";
import Item from "../models/Item.js";
import Notification from "../models/Notification.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const getDashboard = asyncHandler(async (req, res) => {
  const [items, incomingClaims, notifications] = await Promise.all([
    Item.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(6),
    Claim.find()
      .populate({
        path: "itemId",
        match: { userId: req.user._id },
        select: "title status"
      })
      .populate("claimantId", "name rollNumber")
      .sort({ createdAt: -1 }),
    Notification.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(8)
  ]);

  const claimRequests = incomingClaims.filter((claim) => claim.itemId);

  const stats = {
    reportedLost: await Item.countDocuments({ userId: req.user._id, reportType: "lost" }),
    reportedFound: await Item.countDocuments({ userId: req.user._id, reportType: "found" }),
    pendingClaims: claimRequests.filter((claim) => claim.status === "pending").length,
    unreadNotifications: notifications.filter((notification) => !notification.readStatus).length
  };

  res.json({
    success: true,
    data: {
      stats,
      items,
      claimRequests,
      notifications
    }
  });
});
