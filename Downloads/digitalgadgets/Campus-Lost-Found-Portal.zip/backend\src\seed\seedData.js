import dotenv from "dotenv";
import mongoose from "mongoose";

import { connectDatabase } from "../config/db.js";
import Claim from "../models/Claim.js";
import Item from "../models/Item.js";
import Notification from "../models/Notification.js";
import User from "../models/User.js";

dotenv.config();

const users = [
  { name: "Aarav Sharma", rollNumber: "2023001233", password: "campus123", role: "student" },
  { name: "Ishita Roy", rollNumber: "2023001456", password: "campus123", role: "student" },
  { name: "Rahul Mehta", rollNumber: "2023001789", password: "campus123", role: "student" },
  { name: "Sneha Iyer", rollNumber: "2023002234", password: "campus123", role: "student" },
  { name: "Neel Patel", rollNumber: "2023003120", password: "campus123", role: "student" },
  { name: "Diya Nair", rollNumber: "2024001111", password: "campus123", role: "student" },
  { name: "Aditya Singh", rollNumber: "2024001333", password: "campus123", role: "student" },
  { name: "Meera Joshi", rollNumber: "2024001777", password: "campus123", role: "student" },
  { name: "Kabir Khan", rollNumber: "2024002455", password: "campus123", role: "student" },
  { name: "Campus Admin", rollNumber: "2023000001", password: "admin123", role: "admin" }
];

const itemBlueprints = [
  ["MacBook Air Sleeve", "Electronics", "Black laptop sleeve with a coding club sticker.", "lost", "2026-03-22", "Library 2nd Floor"],
  ["Scientific Calculator", "Electronics", "Casio calculator with initials RM on the back.", "found", "2026-03-23", "Engineering Block Room 204"],
  ["College ID Card", "ID Cards", "Blue lanyard attached, belongs to a CSE student.", "lost", "2026-03-24", "Main Cafeteria"],
  ["Blue Water Bottle", "Accessories", "Steel bottle with dent near the cap.", "found", "2026-03-24", "Basketball Court"],
  ["Digital Drawing Tablet", "Electronics", "Small black pen tablet in a grey sleeve.", "lost", "2026-03-26", "Design Lab"],
  ["Discrete Mathematics Book", "Books", "Name written as Sneha on first page.", "found", "2026-03-27", "Library Ground Floor"],
  ["Samsung Buds Case", "Electronics", "White earbuds case with minor scratches.", "lost", "2026-03-27", "Auditorium"],
  ["Black Wallet", "Accessories", "Contains metro card and one photo.", "found", "2026-03-28", "Hostel A Lobby"],
  ["Physics Lab Record", "Books", "Brown cover file with practical sheets.", "lost", "2026-03-28", "Physics Lab"],
  ["Grey Hoodie", "Accessories", "College fest hoodie size M.", "found", "2026-03-29", "Seminar Hall"],
  ["USB Drive 64GB", "Electronics", "Metallic USB with red keyring.", "lost", "2026-03-30", "Computer Lab 3"],
  ["Python Programming Notes", "Books", "Spiral notebook with green sticky tabs.", "found", "2026-03-31", "Reading Room"],
  ["Rose Gold Watch", "Accessories", "Analog watch with a slightly loose strap.", "lost", "2026-03-25", "Girls Hostel Corridor"],
  ["AirPods Charging Case", "Electronics", "Plain white case, no earbuds inside.", "found", "2026-03-25", "Library 2nd Floor"],
  ["Student Bus Pass", "ID Cards", "Bus pass holder with transparent cover.", "lost", "2026-03-26", "Campus Gate"],
  ["Organic Chemistry Textbook", "Books", "Highlighted chapters 3 and 4.", "found", "2026-03-26", "Chemistry Block"],
  ["Silver Ring", "Accessories", "Thin silver ring with engraved star.", "lost", "2026-03-30", "Open Air Theatre"],
  ["Pendrive with Blue Cap", "Electronics", "16GB pendrive containing project files.", "found", "2026-03-30", "Computer Lab 3"],
  ["Brown Notebook", "Books", "Contains startup ideas and lecture notes.", "lost", "2026-03-21", "Innovation Hub"],
  ["Helmet Key", "Accessories", "Single key with yellow rubber cover.", "found", "2026-03-21", "Parking Lot B"]
];

const notificationTemplates = [
  "A possible match was found for your missing item.",
  "A new claim request needs your review.",
  "Your claim request has been approved.",
  "Your item report was flagged as high priority."
];

const seed = async () => {
  await connectDatabase();

  await Promise.all([
    User.deleteMany({}),
    Item.deleteMany({}),
    Claim.deleteMany({}),
    Notification.deleteMany({})
  ]);

  const createdUsers = await User.create(users);

  const createdItems = await Item.insertMany(
    itemBlueprints.map((item, index) => ({
      title: item[0],
      category: item[1],
      description: item[2],
      reportType: item[3],
      status: item[3] === "lost" ? "lost" : "found",
      date: new Date(item[4]),
      location: item[5],
      imageUrl: "",
      userId: createdUsers[index % 8]._id,
      contactPreference: index % 2 === 0 ? "email" : "in-app chat",
      storageLocation: item[3] === "found" ? (index % 2 === 0 ? "Security Office" : "With Me") : ""
    }))
  );

  await Claim.insertMany([
    {
      itemId: createdItems[1]._id,
      claimantId: createdUsers[0]._id,
      proofDescription: "Calculator has a tiny crack near the display and RM initials.",
      additionalNotes: "I can identify the exact keypad sticker.",
      status: "pending"
    },
    {
      itemId: createdItems[5]._id,
      claimantId: createdUsers[3]._id,
      proofDescription: "My name Sneha is written inside the front cover.",
      additionalNotes: "",
      status: "approved"
    },
    {
      itemId: createdItems[7]._id,
      claimantId: createdUsers[2]._id,
      proofDescription: "Wallet contains my metro smart card ending in 7812.",
      additionalNotes: "",
      status: "pending"
    },
    {
      itemId: createdItems[13]._id,
      claimantId: createdUsers[5]._id,
      proofDescription: "Charging case lid has a small pen mark inside.",
      additionalNotes: "Lost it after afternoon lab.",
      status: "rejected"
    },
    {
      itemId: createdItems[17]._id,
      claimantId: createdUsers[6]._id,
      proofDescription: "Pendrive contains our database mini project and attendance sheet.",
      additionalNotes: "",
      status: "pending"
    }
  ]);

  createdItems[5].status = "verified";
  createdItems[5].claimCount = 1;
  createdItems[1].status = "claimed";
  createdItems[7].status = "claimed";
  createdItems[13].status = "found";
  createdItems[17].status = "claimed";
  await Promise.all(createdItems.map((item) => item.save()));

  await Notification.insertMany(
    createdUsers.flatMap((user, index) =>
      notificationTemplates.slice(0, index % 4).map((message, messageIndex) => ({
        userId: user._id,
        message,
        type: messageIndex === 0 ? "match" : messageIndex === 1 ? "claim" : "system",
        readStatus: messageIndex % 2 === 0
      }))
    )
  );

  console.log("Seed data inserted successfully");
  await mongoose.connection.close();
};

seed().catch(async (error) => {
  console.error("Seeding failed:", error);
  await mongoose.connection.close();
  process.exit(1);
});
