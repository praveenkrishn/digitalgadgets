import { Navigate, Route, Routes } from "react-router-dom";

import MainLayout from "./layouts/MainLayout.jsx";
import AuthPage from "./pages/AuthPage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import HomePage from "./pages/HomePage.jsx";
import ItemDetailPage from "./pages/ItemDetailPage.jsx";
import ReportItemPage from "./pages/ReportItemPage.jsx";
import AdminPage from "./pages/AdminPage.jsx";
import { useAuth } from "./context/AuthContext.jsx";

const ProtectedRoute = ({ children, adminOnly = false }) => {
  const { isAuthenticated, user } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (adminOnly && user?.role !== "admin") {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

const App = () => (
  <Routes>
    <Route element={<MainLayout />}>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<AuthPage mode="login" />} />
      <Route path="/signup" element={<AuthPage mode="signup" />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/report/lost"
        element={
          <ProtectedRoute>
            <ReportItemPage reportType="lost" />
          </ProtectedRoute>
        }
      />
      <Route
        path="/report/found"
        element={
          <ProtectedRoute>
            <ReportItemPage reportType="found" />
          </ProtectedRoute>
        }
      />
      <Route path="/items/:id" element={<ItemDetailPage />} />
      <Route
        path="/admin"
        element={
          <ProtectedRoute adminOnly>
            <AdminPage />
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Route>
  </Routes>
);

export default App;
