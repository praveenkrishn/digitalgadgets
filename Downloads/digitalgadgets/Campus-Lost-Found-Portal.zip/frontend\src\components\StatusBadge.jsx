import { statusColors } from "../utils/constants";

const StatusBadge = ({ status }) => (
  <span className={`status-badge ${statusColors[status] || ""}`}>{status}</span>
);

export default StatusBadge;
