import mongoose from "mongoose";

const itemSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true },
    category: {
      type: String,
      enum: ["Electronics", "Books", "ID Cards", "Accessories", "Others"],
      required: true
    },
    reportType: {
      type: String,
      enum: ["lost", "found"],
      required: true
    },
    status: {
      type: String,
      enum: ["lost", "found", "claimed", "verified"],
      required: true
    },
    date: { type: Date, required: true },
    location: { type: String, required: true, trim: true },
    imageUrl: { type: String, default: "" },
    contactPreference: {
      type: String,
      enum: ["email", "in-app chat"],
      default: "email"
    },
    storageLocation: { type: String, default: "" },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    claimCount: {
      type: Number,
      default: 0
    }
  },
  {
    timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" }
  }
);

itemSchema.index({ title: "text", description: "text", location: "text" });

const Item = mongoose.model("Item", itemSchema);

export default Item;
