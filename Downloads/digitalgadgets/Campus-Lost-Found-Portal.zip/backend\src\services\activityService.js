import ActivityLog from "../models/ActivityLog.js";

export const logActivity = async ({ actorId, action, details }) =>
  ActivityLog.create({
    actorId,
    action,
    details
  });
