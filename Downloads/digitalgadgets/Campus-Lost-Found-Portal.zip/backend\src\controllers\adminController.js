import ActivityLog from "../models/ActivityLog.js";
import Claim from "../models/Claim.js";
import Item from "../models/Item.js";
import User from "../models/User.js";
import { logActivity } from "../services/activityService.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const getAdminOverview = asyncHandler(async (req, res) => {
  const [users, items, claims, logs] = await Promise.all([
    User.find().select("-password").sort({ createdAt: -1 }),
    Item.find().populate("userId", "name rollNumber role").sort({ createdAt: -1 }),
    Claim.find()
      .populate("claimantId", "name rollNumber")
      .populate("itemId", "title status")
      .sort({ createdAt: -1 }),
    ActivityLog.find().sort({ createdAt: -1 }).limit(20)
  ]);

  res.json({
    success: true,
    data: {
      summary: {
        totalUsers: users.length,
        totalItems: items.length,
        totalClaims: claims.length,
        verifiedItems: items.filter((item) => item.status === "verified").length
      },
      users,
      items,
      claims,
      logs
    }
  });
});

export const deleteSpamItem = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.itemId);

  if (!item) {
    const error = new Error("Item not found");
    error.statusCode = 404;
    throw error;
  }

  await item.deleteOne();
  await Claim.deleteMany({ itemId: item._id });

  await logActivity({
    actorId: req.user._id,
    action: "admin.item.deleted",
    details: `Admin ${req.user.name} removed item ${item.title}`
  });

  res.json({
    success: true,
    message: "Item removed"
  });
});
