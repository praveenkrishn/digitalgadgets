const SectionHeader = ({ title, description, action }) => (
  <div className="section-header">
    <div>
      <h2>{title}</h2>
      {description ? <p className="muted">{description}</p> : null}
    </div>
    {action}
  </div>
);

export default SectionHeader;
