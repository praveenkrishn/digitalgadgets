import { body, query } from "express-validator";

import Claim from "../models/Claim.js";
import Item from "../models/Item.js";
import { logActivity } from "../services/activityService.js";
import { uploadImageIfPresent } from "../services/imageService.js";
import { findPossibleMatches } from "../services/matchingService.js";
import { createNotification } from "../services/notificationService.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const itemValidation = [
  body("title").trim().notEmpty().withMessage("Item title is required"),
  body("category")
    .isIn(["Electronics", "Books", "ID Cards", "Accessories", "Others"])
    .withMessage("Invalid category"),
  body("description").trim().notEmpty().withMessage("Description is required"),
  body("date")
    .isISO8601()
    .withMessage("Valid date is required")
    .custom((value) => new Date(value) <= new Date())
    .withMessage("Date cannot be in the future"),
  body("location").trim().notEmpty().withMessage("Location is required"),
  body("reportType").isIn(["lost", "found"]).withMessage("Invalid report type"),
  body("contactPreference").optional().isIn(["email", "in-app chat"]),
  body("storageLocation").optional().trim()
];

export const itemQueryValidation = [
  query("status").optional().isIn(["lost", "found", "claimed", "verified"]),
  query("sort").optional().isIn(["latest", "oldest"])
];

export const createItem = asyncHandler(async (req, res) => {
  const imageUrl = await uploadImageIfPresent(req.file);
  const status = req.body.reportType === "lost" ? "lost" : "found";

  const item = await Item.create({
    title: req.body.title,
    description: req.body.description,
    category: req.body.category,
    reportType: req.body.reportType,
    status,
    date: req.body.date,
    location: req.body.location,
    imageUrl,
    contactPreference: req.body.contactPreference || "email",
    storageLocation: req.body.storageLocation || "",
    userId: req.user._id
  });

  const savedItem = await Item.findById(item._id).populate("userId", "name rollNumber role");
  const matches = await findPossibleMatches(savedItem);

  await Promise.all(
    matches.map((match) =>
      createNotification({
        userId: match.userId._id,
        type: "match",
        message: `A possible match was detected for "${savedItem.title}".`
      })
    )
  );

  await logActivity({
    actorId: req.user._id,
    action: "item.created",
    details: `${req.user.name} reported a ${savedItem.reportType} item: ${savedItem.title}`
  });

  res.status(201).json({
    success: true,
    data: {
      item: savedItem,
      possibleMatches: matches
    }
  });
});

export const getItems = asyncHandler(async (req, res) => {
  const { keyword, category, status, location, startDate, endDate, sort = "latest" } = req.query;
  const filters = {};

  if (keyword) {
    filters.$or = [
      { title: { $regex: keyword, $options: "i" } },
      { description: { $regex: keyword, $options: "i" } }
    ];
  }

  if (category) filters.category = category;
  if (status) filters.status = status;
  if (location) filters.location = { $regex: location, $options: "i" };

  if (startDate || endDate) {
    filters.date = {};
    if (startDate) filters.date.$gte = new Date(startDate);
    if (endDate) filters.date.$lte = new Date(endDate);
  }

  const items = await Item.find(filters)
    .populate("userId", "name rollNumber role")
    .sort({ createdAt: sort === "oldest" ? 1 : -1 });

  res.json({ success: true, data: items });
});

export const getItemById = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id).populate("userId", "name rollNumber role");

  if (!item) {
    const error = new Error("Item not found");
    error.statusCode = 404;
    throw error;
  }

  const possibleMatches = await findPossibleMatches(item);
  const claims = await Claim.find({ itemId: item._id })
    .populate("claimantId", "name rollNumber")
    .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: {
      item,
      possibleMatches,
      claims
    }
  });
});

export const getMyItems = asyncHandler(async (req, res) => {
  const items = await Item.find({ userId: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, data: items });
});

export const deleteItem = asyncHandler(async (req, res) => {
  const item = await Item.findById(req.params.id);

  if (!item) {
    const error = new Error("Item not found");
    error.statusCode = 404;
    throw error;
  }

  const isOwner = item.userId.toString() === req.user._id.toString();
  const isAdmin = req.user.role === "admin";

  if (!isOwner && !isAdmin) {
    const error = new Error("You cannot delete this item");
    error.statusCode = 403;
    throw error;
  }

  await item.deleteOne();
  await Claim.deleteMany({ itemId: item._id });

  await logActivity({
    actorId: req.user._id,
    action: "item.deleted",
    details: `${req.user.name} deleted item ${item.title}`
  });

  res.json({ success: true, message: "Item deleted successfully" });
});
