# Campus Lost & Found Portal

A production-ready full-stack campus lost and found application built with React, Express, MongoDB, JWT authentication, seeded demo data, smart item matching, claim workflows, notifications, and an admin dashboard.

## Stack

- Frontend: React + Vite + React Router + Axios
- Backend: Node.js + Express + MongoDB + Mongoose
- Auth: JWT + bcrypt
- Image storage: Cloudinary-ready with local URL fallback
- Deployment targets: Vercel/Netlify for frontend, Render/Railway for backend, MongoDB Atlas for database

## Quick Start

1. Install dependencies:

```powershell
npm.cmd install
```

2. Copy environment templates:

```powershell
Copy-Item backend\\.env.example backend\\.env
Copy-Item frontend\\.env.example frontend\\.env
```

3. Update the environment values.

4. Seed sample data:

```powershell
npm.cmd run seed --workspace backend
```

5. Run both apps:

```powershell
npm.cmd run dev
```

## Demo Accounts

- Student: `2023001233` / `campus123`
- Student: `2024001111` / `campus123`
- Admin: `2023000001` / `admin123`

## Features

- Roll-number-based signup and login
- Lost and found item reporting with validation
- Search, filters, sorting, and dashboard summaries
- Smart matching between lost and found items
- Claim request workflow with approval and rejection
- In-app notifications and activity tracking
- Admin moderation tools
- Responsive UI with light/dark mode toggle
