import express from "express";

import { deleteSpamItem, getAdminOverview } from "../controllers/adminController.js";
import { authorize, protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect, authorize("admin"));
router.get("/overview", getAdminOverview);
router.delete("/items/:itemId", deleteSpamItem);

export default router;
